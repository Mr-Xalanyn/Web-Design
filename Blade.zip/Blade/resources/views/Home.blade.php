@extends('index')

@section('content')
    This is the Home Page
@endsection
