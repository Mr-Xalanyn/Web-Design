This is just a demonstration on using authentication in Laravel, using Jetstream, PhpStorm, HeidiSQL, and Laragon.

-When you type in your project url (eg. 127.0.0.1:8000), click on 'Register' and you can type in your personal info and it'll be stored in the database. Then, you can log out and login with your previously registered account info.

-After your initial registration you can login with your email, phone number or your name, additional to your password, ofc.

-Vendors and node module files are removed

This is also published on my GitHub at 'Mr-Xalanyn'/ Web-Design